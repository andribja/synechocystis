%load iJN678;

% R00178 AUKAHVARF FYRIR CCOAOMT
model = addReaction(model, 'S-adenosyl-L-methionine carboxy-lyase', 'amet[c] + h[c]  <=> ametam[c] + co2[c] ');
 
%R00697
model = addReaction(model, 'PAL', 'phe-L[c]  <=> cinnam[c] + nh3[c] ');
 
%R00737
model = addReaction(model, 'PTAL', 'tyr-L[c]  <=> coumac[c] + nh3[c] ');
 
%R02253 C4H eða CA4H
model = addReaction(model, 'trans-cinnamate 4-monooxygenase', 'cinnam[c] + o2[c] + nadph[c] + h[c]  <=> coumac[c] + nadp[c] + h2o[c] ');
 
%R01616
model = addReaction(model, '4-coumarate---CoA ligase a', 'atp[c] + coumac[c] + coa[c]  <=> amp[c] + ppi[c] + coumcoa[c] ');
 
%R02416
model = addReaction(model, 'shikimate O-hydroxycinnamoyltransferase a', 'coumcoa[c] + skm[c]  <=> coa[c] + 4coumshik[c] ');
 
%R08815 C4H eða CA4H
model = addReaction(model, 'trans-cinnamate 4-monooxygenase b', '4coumshik[c] + o2[c] + nadph[c] + h[c]  <=> ox4coumshik[c] + nadp[c] + h2o[c] ');
 
%R07433
model = addReaction(model, 'shikimate O-hydroxycinnamoyltransferase b', 'ox4coumshik[c] + coa[c]  <=> caffcoa[c] + skm[c] ');
 
%R02193
model = addReaction(model, 'cinnamoyl-CoA reductase b', 'conifald[c] + coa[c] + nadp[c]  <=> ferulcoa[c] + nadph[c] + h[c] ');

model = addReaction(model, 'EX_ferulcoa(e)', 'ferulcoa[c]  <=> ');
 
%R02194
model = addReaction(model, '4-coumarate---CoA ligase', 'atp[c] + ferulac[c] + coa[c]  <=> ad2p[c] + pyrphosAc[c] + ferulcoa[c] ');
 
% R07436
model = addReaction(model, 'p-coumaroyl-CoA:caffeoyl-CoA 3-hydrolase', 'coumcoa[c] + h2o[c]  <=> caffcoa[c] + h[c] ');
 
% R05772
model = addReaction(model, 'trans-feruloyl-CoA hydratase', 'ferulcoa[c] + h2o[c]  <=> hydpropcoa[c] ');
 
% R05773
model = addReaction(model, 'vanillin lyase', 'hydpropcoa[c]  <=> accoa[c] + vanil[c] ');

% Seyting 
model = addReaction(model, 'EX_vanil(e)', 'vanil[c]  <=> ');

% Aldehyde dehydrogenase
model = addReaction(model, 'Aldehyde dehydrogenase asdf', 'conifald[c] + nad[c] + h2o[c]  <=> ferulac[c] + nadh[c] + h[c] ');
 
 
model = changeObjective(model, 'EX_vanil(e)');

sol = optimizeCbModel(model);
disp(sol);
 
%robustnessAnalysis(model, 'Ec_biomass_SynAuto');
 
model = changeRxnBounds(model, 'EX_co2(e)', 0, 'b');
 
sol = optimizeCbModel(model);
disp(sol);
 
robustnessAnalysis(model, 'Ec_biomass_SynAuto');
